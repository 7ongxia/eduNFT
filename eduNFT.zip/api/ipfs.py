from fastapi import APIRouter, Path
from passlib.context import CryptContext

router = APIRouter(prefix="/ipfs", tags=["ipfs"])
metadata_order = {
    "name": "Order API Version 1",
    "description": "Version 1 ORDER API"
}


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
class Hasher():
    @staticmethod
    def verify_password(plain_password, hashed_password):
        return pwd_context.verify(plain_password, hashed_password)

    @staticmethod
    def get_password_hash(password):
        return pwd_context.hash(password)


@router.get(
    path="", summary="GET ipfs"
)
async def get_orders():
    hashed_password = Hasher.get_password_hash("user.password")
    return {"message": hashed_password}


@router.post(
    path="", summary="POST Orders"
)
async def register_order():
    return {"message": "Register Order"}


@router.patch(
    path="/{order_id}", summary="PATCH Orders"
)
async def update_order(order_id: int = Path(..., title="Order Number")):
    return {"message": f"Update Order by {order_id}"}


@router.delete(
    path="/{order_id}", summary="DELETE Orders"
)
async def delete_order(order_id: int = Path(..., title="Order Number")):
    return {"message": f"Delete Order by {order_id}"}